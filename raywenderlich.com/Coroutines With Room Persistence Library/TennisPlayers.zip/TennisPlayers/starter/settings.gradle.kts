rootProject.name="TennisPlayers"
include (":app")
